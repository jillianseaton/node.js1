Stripe.api_key = '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 = 'sk_test_51RBGS0K9RLxvHin2pxNnWmgcoPaM6BElRs4XF06xKHOW2XrzFZWjdoWmjoYFUSTEnBAcO1lFTx2I32pcnzS8gv7z00mJAlZ6o8'

account = Stripe::Account.create({
  country: 'US',
  email: 'jenny.rosen@example.com',
  controller: {
    fees: {payer: 'application'},
    losses: {payments: 'application'},
    stripe_dashboard: {type: 'express'},
  },
})'

account = Stripe::Account.create({
  country: 'US',
  email: 'jillianseaton1303@gmail.com',
  controller: {
    fees: {payer: 'application'},
    losses: {payments: 'application'},
    stripe_dashboard: {type: 'express'},
  },
})